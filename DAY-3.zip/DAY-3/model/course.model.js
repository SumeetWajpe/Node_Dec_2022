let courses = [
  {
    id: 1,
    title: "React",
    price: 5000,
    likes: 400,
    rating: 5,

    imageUrl:
      "https://ms314006.github.io/static/b7a8f321b0bbc07ca9b9d22a7a505ed5/97b31/React.jpg",
    description:
      "React is a free and open-source front-end JavaScript library for building user interfaces or UI components. It is maintained by Facebook and a community of individual developers and companies. React can be used as a base in the development of single-page or mobile applications.",
  },
  {
    id: 2,
    title: "Redux",
    price: 4000,
    likes: 600,
    rating: 5,

    imageUrl: "https://logicalidea.co/wp-content/uploads/2020/05/Redux.jpg",
    description:
      "Redux ; Predictable. Redux helps you write applications that behave consistently ; Centralized. Centralizing your application's state and logic enables powerful .",
  },
  {
    id: 3,
    title: "Node",
    price: 6000,
    likes: 900,
    rating: 4,

    imageUrl:
      "https://www.techgeekpuzzle.com/wp-content/uploads/2020/11/nodejs.png",
    description:
      "As an asynchronous event-driven JavaScript runtime, Node.js is designed to build scalable network applications. In the following hello world example, many connections can be handled concurrently. Upon each connection, the callback is fired, but if there is no work to be done, Node.js will sleep.",
  },
  {
    id: 4,
    title: "Angular",
    price: 5000,
    likes: 200,
    rating: 3,

    imageUrl: "https://miro.medium.com/max/1100/1*dYhDHdCt0lhVRdj0IjrI7A.png",
    description:
      "Angular is a platform and framework for building single-page client applications using HTML and TypeScript. Angular is written in TypeScript. It implements core and optional functionality as a set of TypeScript libraries that you import into your applications.",
  },
  {
    id: 5,
    title: "Flutter",
    price: 7000,
    likes: 700,
    rating: 4,

    imageUrl: "https://miro.medium.com/max/2000/1*PCKC8Ufml-wvb9Vjj3aaWw.jpeg",
    description:
      "Control every pixel to create customized & adaptive designs that look great on any screen. Take control of your codebase with plugins, testing, dev tools & build high quality apps. Hot Reload. Null Safe Code. Flexible UI. Fast Development. Single Codebase. Web Stable.",
  },
];
module.exports = courses;

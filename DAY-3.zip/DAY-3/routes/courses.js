const express = require("express");
var courses = require("../../onlinetraining_pug/model/course.model");

let router = express.Router();

router.route("/").get((req, res) => {
  res.render("courses", { listofcourses: courses, title: "List Of Courses" });
});

router.route("/coursedetails/:cid").get((req, res) => {
  let courseId = +req.params.cid;
  let course = courses.find(c => c.id === courseId);
  res.render("coursedetails", { course });
});

module.exports = router;

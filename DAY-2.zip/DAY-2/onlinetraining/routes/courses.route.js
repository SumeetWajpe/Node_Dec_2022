const express = require("express");
const router = express.Router();
let courses = require("../models/course.model");

router.get("/", (req, res) => {
  res.json(courses);
});

router.delete("/:id", (req, res) => {
  let courseId = req.params.id;
  console.log(courseId);
  // delete logic
  courses = courses.filter(course => course.id != courseId);
  console.log(courses);
  res.json({
    message: `Course with Id : ${courseId} Deleted successfully !`,
    status: "success",
  });
});

router.post("/newcourse", (req, res) => {
  console.log(req.body);
});

module.exports = router;

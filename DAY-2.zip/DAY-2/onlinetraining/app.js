const express = require("express");
const path = require("path");
const coursesRouter = require("./routes/courses.route");

const app = express(); // represents an application

// middlewares
app.use(express.static(path.join(__dirname, "static")));
app.use(express.json()); // reads json data from request body and populates body property
app.use("/courses", coursesRouter);

app.get("/", (req, res) => {
  res.sendFile("Courses.html", { root: __dirname });
});

app.use((req, res) => {
  res.status(404).send("Resource Not Found !");
});

app.listen(4000, () => {
  console.log("Express running at 4000 !");
});

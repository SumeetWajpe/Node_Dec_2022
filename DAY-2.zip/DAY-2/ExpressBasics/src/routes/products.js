const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  let products = [{ name: "Macbook Pro" }, { name: "Macbook Air" }];
  res.json(products);
});

// app.get("/products", (req, res) => {
//   let products = [{ name: "Macbook Pro" }, { name: "Macbook Air" }];
//   res.json(products);
// });

module.exports = router;

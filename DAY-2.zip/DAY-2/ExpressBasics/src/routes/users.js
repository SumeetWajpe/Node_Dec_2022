const express = require("express");
const router = express.Router();
let users = [
  { id: 1, name: "First User" },
  { id: 2, name: "Second User " },
];
router.get("/", (req, res) => {
  res.json(users);
});

router.get("/:id", (req, res) => {
  console.log(req.params.id);
  let theUser = users.find(user => user.id == req.params.id);
  res.json(theUser);
});

module.exports = router;

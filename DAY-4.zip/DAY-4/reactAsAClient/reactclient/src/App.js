import logo from "./logo.svg";
import "./App.css";

import { useEffect } from "react";

function App() {
  useEffect(() => {
    fetch("http://localhost:4000/courses")
      .then(res => res.json())
      .then(courses => console.log(courses));
  }, []);

  return <div className="App">List of Courses</div>;
}

export default App;

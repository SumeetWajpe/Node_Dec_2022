const socket = require("socket.io");
const express = require("express");
const fs = require("fs");
const http = require("http");

let server = http.createServer((req, res) => {
  fs.readFile("ClientPeer.html", (err, data) => {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    res.end(data);
  });
});

var io = socket(server);
io.sockets.on("connection", skt => {
  setInterval(() => {
    var dataToBeSent = new Date();
    skt.emit("custom_msg_from_server_peer", dataToBeSent);
  }, 2000);

  skt.on("custom_msg_from_client_peer", dataFromClient => {
    console.log("Data from Client Peer : " + dataFromClient);
  });
});

server.listen(3000, () => {
  console.log("Server running @ port 3000 !");
});

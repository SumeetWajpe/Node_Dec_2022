const http = require("http");
const fs = require("fs");
const hostname = "127.0.0.1";
const port = 3000;

const server = http.createServer((req, res) => {
  //   console.log(req.url);
  if (req.url == "/") {
    res.statusCode = 200;
    res.setHeader("Content-Type", "text/html");
    const readableStream = fs.createReadStream("Index.html");
    readableStream.pipe(res);
  } else if (req.url == "/script.js") {
    res.statusCode = 200;
    const readableStream = fs.createReadStream("script.js");
    readableStream.pipe(res);
  } else if (req.url == "/products") {
    res.statusCode = 200;
    let products = [{ name: "Macbook Pro" }, { name: "Macbook Air" }];
    res.setHeader("Content-Type", "application/json");
    res.end(JSON.stringify(products));
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});

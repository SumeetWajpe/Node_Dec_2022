const fs = require("fs");

const readableStream = fs.createReadStream("Input.txt");
const writeableStream = fs.createWriteStream("Output.txt");
// let data = "";
// readableStream.on("data", function (chunk) {
//   console.log("\n\r>>>>>>>>>>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>>>>>>>\n\r");
//   data += chunk.toString();
// });

// readableStream.on("end", function () {
//   writeableStream.write(data);
//   writeableStream.end();
// });

readableStream.pipe(writeableStream);

console.log("Hello Node !");

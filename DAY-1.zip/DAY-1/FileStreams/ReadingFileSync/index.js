const fs = require("fs");

try {
  const dataFromFile = fs.readFileSync("Input.txt", { encoding: "utf-8" });
  console.log(dataFromFile);
} catch (error) {
  console.log(error);
}
console.log("Program Ended !");

const fs = require("fs");

fs.readFile("Input.txt", "utf-8",(err, dataFromFile) => {
  if (err) {
    console.log(err);
  } else {
    console.log(dataFromFile);
  }
});
console.log("Program Ended !");

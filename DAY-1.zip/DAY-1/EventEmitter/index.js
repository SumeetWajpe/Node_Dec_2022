const EventEmitter = require("events").EventEmitter;
// publisher
function GetCount(maxIteration) {
  // emit

  let e = new EventEmitter();

  //setTimeout(() => e.emit("count", 1), 500); // !the node way !

  process.nextTick(() => {
    e.emit("start");
    let counter = 0;
    let t = setInterval(() => {
      if (counter < maxIteration) {
        e.emit("count", counter++);
      }
      if (counter == maxIteration) {
        e.emit("end", counter);
        clearInterval(t);
      }
      if (counter >= 8) {
        e.emit("error", counter);
        clearInterval(t);
      }
    }, 500);
  });
  return e;
}

// subscriber
let evtEmitter = GetCount(10);
evtEmitter.on("start", function () {
  console.log("Iteration started !");
});
evtEmitter.on("count", function (iterationData) {
  console.log("Received : " + iterationData);
});
evtEmitter.on("end", function (iterationData) {
  console.log("Iteration Ended with final count : " + iterationData);
});
evtEmitter.on("error", function (iterationData) {
  console.log("Iteration Ended with Error with count : " + iterationData);
});
console.log("Program Ended !");

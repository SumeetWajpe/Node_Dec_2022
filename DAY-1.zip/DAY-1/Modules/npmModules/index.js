const axios = require("axios");

axios
  .get("https://api.github.com/users")
  .then(response => {
    // handle success
    console.log(response.data);
  })
  .catch(function (error) {
    // handle error
    console.log(error);
  })
  .finally(function () {
    // always executed
  });

// fetch is a browser web api (not available with node)
// fetch("https://jsonplaceholder.typicode.com/posts")
//   .then(res => res.json())
//   .then(posts => console.log(posts));

//setTimeout(() => console.log("Available in node as well !")); // made available

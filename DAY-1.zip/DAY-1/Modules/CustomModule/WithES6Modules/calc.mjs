import { Add } from "./math.mjs";
console.log(`The addition is ${Add(20, 40)}`);

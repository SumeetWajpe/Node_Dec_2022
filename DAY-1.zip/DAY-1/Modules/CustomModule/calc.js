const math = require("./math");

console.log(`The addition is ${math.Addition(20, 40)}`);
console.log(`The product is ${math.Product(20, 40)}`);

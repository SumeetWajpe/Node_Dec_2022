const express = require("express");
const mongoose = require("mongoose");
const app = express();

const Products = require("./models/products"); // Mongoose model (apis & methods defined)

mongoose.connect("mongodb://127.0.0.1:27017/productsdb");

mongoose.connection.once("open", () => {
  console.log("Connected to Database !");
});

app.get("/", async (req, res) => {
  res.send("Using MongoDB with Node !");
  const listOfProducts = await Products.find({});
  console.log(listOfProducts);
});

app.listen(4000, () => {
  console.log("Server running @ port 4000 !");
});

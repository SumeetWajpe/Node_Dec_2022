const sum = require("./add");

// test("adds 1 + 2 to equal 3", () => {
//   expect(sum(1, 2)).toBe(3);
// });

// test suite
describe("addition test suite", () => {
  it("add two numbers", () => {
    //Arrange
    let result = 30;
    //Act
    let actualResult = sum(20, 10);
    //Assert
    expect(actualResult).toBe(result);
  });
});

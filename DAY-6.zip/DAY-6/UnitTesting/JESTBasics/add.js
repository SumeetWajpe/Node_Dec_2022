function sum(a, b) {
  return a + b;
}

function difference(a, b) {
  return a - b;
}
module.exports = sum;

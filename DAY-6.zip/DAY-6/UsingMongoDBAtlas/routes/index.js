var express = require("express");
var router = express.Router();
const Products = require("../models/products"); // Mongoose model (apis & methods defined)

/* GET home page. */
router.get("/", async function (req, res, next) {
  const products = await Products.find({});
  console.log(products);
  res.render("index", { title: "Product List", products });
});

module.exports = router;
